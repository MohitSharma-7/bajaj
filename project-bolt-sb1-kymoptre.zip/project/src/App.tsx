import React, { useState } from 'react';
import { Listbox } from '@headlessui/react';
import { ChevronsDownUp as ChevronUpDown } from 'lucide-react';

const filters = [
  { id: 'numbers', name: 'Numbers' },
  { id: 'alphabets', name: 'Alphabets' },
  { id: 'highest_alphabet', name: 'Highest Alphabet' }
];

// Replace this with your actual backend URL after deployment
const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000';

function App() {
  const [input, setInput] = useState('');
  const [error, setError] = useState('');
  const [response, setResponse] = useState<any>(null);
  const [selectedFilters, setSelectedFilters] = useState<string[]>([]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    try {
      const parsedInput = JSON.parse(input);
      
      const res = await fetch(`${API_URL}/bfhl`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(parsedInput)
      });
      
      const data = await res.json();
      setResponse(data);
    } catch (err) {
      setError('Invalid JSON format');
    }
  };

  const getFilteredResponse = () => {
    if (!response || !response.is_success) return null;

    const filtered: any = {};
    selectedFilters.forEach(filter => {
      filtered[filter] = response[filter];
    });
    return filtered;
  };

  const filteredResponse = getFilteredResponse();

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="max-w-3xl mx-auto">
        <form onSubmit={handleSubmit} className="space-y-4 mb-8">
          <div>
            <label htmlFor="json-input" className="block text-sm font-medium text-gray-700 mb-2">
              Enter JSON Input
            </label>
            <textarea
              id="json-input"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              className="w-full h-32 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
              placeholder='{"data": ["M","1","334","4","B"]}'
            />
          </div>
          {error && (
            <p className="text-red-600 text-sm">{error}</p>
          )}
          <button
            type="submit"
            className="w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
          >
            Submit
          </button>
        </form>

        {response && response.is_success && (
          <div className="space-y-4">
            <div className="relative">
              <Listbox value={selectedFilters} onChange={setSelectedFilters} multiple>
                <Listbox.Button className="relative w-full bg-white border border-gray-300 rounded-md shadow-sm pl-3 pr-10 py-2 text-left cursor-default focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500">
                  <span className="block truncate">
                    {selectedFilters.length === 0 
                      ? 'Select filters' 
                      : `Selected: ${selectedFilters.join(', ')}`}
                  </span>
                  <span className="absolute inset-y-0 right-0 flex items-center pr-2">
                    <ChevronUpDown className="h-5 w-5 text-gray-400" aria-hidden="true" />
                  </span>
                </Listbox.Button>
                <Listbox.Options className="absolute z-10 mt-1 w-full bg-white shadow-lg max-h-60 rounded-md py-1 text-base ring-1 ring-black ring-opacity-5 overflow-auto focus:outline-none sm:text-sm">
                  {filters.map((filter) => (
                    <Listbox.Option
                      key={filter.id}
                      value={filter.id}
                      className={({ active }) =>
                        `${active ? 'text-white bg-indigo-600' : 'text-gray-900'}
                        cursor-default select-none relative py-2 pl-3 pr-9`
                      }
                    >
                      {filter.name}
                    </Listbox.Option>
                  ))}
                </Listbox.Options>
              </Listbox>
            </div>

            {filteredResponse && (
              <div className="bg-white shadow rounded-lg p-6">
                <h2 className="text-lg font-medium text-gray-900 mb-4">Response</h2>
                <pre className="bg-gray-50 p-4 rounded-md overflow-auto">
                  {JSON.stringify(filteredResponse, null, 2)}
                </pre>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default App;